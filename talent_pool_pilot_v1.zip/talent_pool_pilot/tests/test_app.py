from fastapi.testclient import TestClient
from app.main import app
c=TestClient(app)
def test_health():assert c.get('/health').json()['status']=='ok'
def test_auth_denied():assert c.get('/api/v1/audit',headers={'X-Role':'reclutador'}).status_code==403
def test_deterministic_match():
 p={'required':['Java','Microservicios'],'desired':['AWS'],'years':3,'seniority':'Mid','dedication':100,'location':'Remoto'}
 a=c.post('/api/v1/matches',json=p).json()['results'];b=c.post('/api/v1/matches',json=p).json()['results'];assert [(x['id'],x['score']) for x in a]==[(x['id'],x['score']) for x in b]
def test_empty_text_file():
 r=c.post('/api/v1/documents/extract',files={'file':('a.txt',b'', 'text/plain')});assert r.status_code==200
def test_disallowed_file():
 r=c.post('/api/v1/documents/extract',files={'file':('a.exe',b'MZ','application/octet-stream')});assert r.status_code==415
def test_idempotency():
 p={'title':'Backend Senior','summary':'Vacante de prueba suficientemente extensa','hiring_manager':'manager','recruiter':'recruiter','candidate_ids':['C-001']};h={'Idempotency-Key':'test-fixed-key','X-Role':'reclutador'}
 a=c.post('/api/v1/vacancies',json=p,headers=h).json();b=c.post('/api/v1/vacancies',json=p,headers=h).json();assert a==b
