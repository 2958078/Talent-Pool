# Talent Pool Pilot v1.0

Evolución compatible del prototipo Talent Pool. Conserva carga de demanda, criterios editables, modo ciego, Top 1/2/3, selección de terna, creación estructurada y exportación JSON. Agrega API versionada, SQLite, matching determinístico, idempotencia, auditoría, RBAC demostrativo y pruebas.

## Ejecutar

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Abra `http://127.0.0.1:8000`.

## Pruebas

```bash
pytest -q
```

## Seguridad y alcance

Este paquete está preparado para piloto técnico local. El encabezado `X-Role` demuestra RBAC, pero debe sustituirse por OIDC corporativo. El adaptador ATS es simulado y está etiquetado. Antivirus, OCR, gestor de secretos, WAF, cifrado administrado y observabilidad empresarial requieren servicios externos antes de producción.
