# Acta de decisión

**Decisión actual:** aprobado para demostración técnica local. Aprobación empresarial condicionada.

No se declara listo para piloto empresarial hasta cumplir P0: identidad corporativa, servicios seguros de archivo, base administrada, integración ATS real, seguridad, privacidad, accesibilidad E2E, observabilidad y aprobación de negocio.
