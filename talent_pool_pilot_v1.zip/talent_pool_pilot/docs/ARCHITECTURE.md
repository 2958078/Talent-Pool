# Arquitectura propuesta

- Frontend responsive y accesible.
- API REST `/api/v1` con FastAPI.
- Persistencia piloto SQLite; objetivo empresarial PostgreSQL.
- Matching determinístico basado en reglas versionadas.
- Auditoría separada y restringida.
- Adaptador ATS pendiente de configuración corporativa.
- Objetivo de identidad: OIDC empresarial; el piloto usa encabezados demostrativos.
- Objetivo documental: almacenamiento de objetos, antivirus y OCR externos.

## Flujo

Carga -> validación -> extracción/OCR -> revisión humana -> matching -> selección -> validación -> borrador -> adaptador ATS -> auditoría.
