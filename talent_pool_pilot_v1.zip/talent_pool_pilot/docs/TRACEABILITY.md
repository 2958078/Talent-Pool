# Matriz de continuidad y trazabilidad

| Funcionalidad | Estado anterior | Cambio | Evidencia | Estado final | Riesgo pendiente |
|---|---|---|---|---|---|
| Carga texto/PDF/DOCX/TXT/MD | Frontend | API de validación y extracción | Endpoint y prueba tipo rechazado | Conservada y fortalecida | OCR/antivirus externo |
| Criterios editables | Disponible | Confianza y evidencia | UI piloto | Conservada | NLP avanzado |
| Modo ciego | Disponible | Se mantiene activo | UI y datos anónimos | Conservada | Gobierno de atributos |
| Top 1/2/3 | Datos fijos | Cálculo determinístico | Prueba repetibilidad | Mejorada | Validación negocio |
| Nueve candidatos | Disponible | Pool persistido | Seed SQLite | Conservada | Escala productiva |
| Selección de terna | Frontend | Payload persistido | API vacancies | Mejorada | Flujo de estados |
| JSON | Disponible | Payload ampliado | Botón descarga | Conservada | Esquema corporativo |
| Crear vacante | Simulada | Borrador persistido e idempotente | Prueba idempotencia | Mejorada, no ATS | Adaptador real |
| Auditoría | No disponible | Registro de acciones | Endpoint restringido | Agregada | Inmutabilidad externa |
| RBAC | No disponible | Roles demostrativos | Prueba 403 | Agregada | OIDC real |
