# Backlog

## P0 antes de piloto empresarial
- Sustituir RBAC demostrativo por OIDC corporativo.
- PostgreSQL administrado, cifrado, backups y migraciones.
- Antivirus, almacenamiento seguro y OCR aprobados.
- Adaptador ATS real, secretos, reintentos, circuit breaker e idempotencia distribuida.
- SAST, DAST, dependencias, pentest y revisión de privacidad/legal.

## P1
- Playwright E2E, axe, pruebas multi-navegador y carga.
- Catálogo empresarial de habilidades y sinónimos.
- Historial UI, comparación lado a lado, motivos y estados.
- Métricas, trazas, alertas y dashboards.

## P2
- Exportaciones adicionales, colaboración y analítica agregada aprobada.
