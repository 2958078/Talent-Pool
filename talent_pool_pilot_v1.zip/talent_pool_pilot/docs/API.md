# Contratos API v1

- `POST /api/v1/documents/extract`: multipart, valida MIME/extensión/tamaño; retorna campos, confianza, evidencia y hash.
- `POST /api/v1/matches`: criterios; retorna ranking, dimensiones, bandas, versión y correlation ID.
- `POST /api/v1/vacancies`: payload estructurado; exige `Idempotency-Key`; guarda borrador local.
- `GET /api/v1/vacancies`: lista solicitudes persistidas.
- `GET /api/v1/audit`: solo auditor o administrador.
- `GET /health`: estado y versión.
